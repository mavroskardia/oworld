name = "Staff"
value = 1000
attack = 4
locations = EquipLocation.Two_Handed
types = EquipTypes.Melee
jobs = JobTypes.All
desc = """A walking stick that you can shove up peoples
asses if they mess with you."""
